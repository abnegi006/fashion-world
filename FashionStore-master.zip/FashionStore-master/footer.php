<div style="margin-top: 50px;"> 
    <div> 
        <div style="float: right; margin-right: 140px;">
            <a target="_blank" href="http://youtube.com/user/fashionstar.com"><img src="images/media/youtube-sharing.png"></a> 
            <a target="_blank" href="https://plus.google.com/fashionstar.com"><img src="images/media/google-plus-sharing.png"></a> 
            <a target="_blank" href="http://www.facebook.com/fashionstar.com"><img src="images/media/facebook-sharing.png"></a> 
            <a target="_blank" href="https://twitter.com/fashionstar.com"><img src="images/media/twitter-sharing.png"></a> 
        </div> 
    </div> 
    <div > 
        <div style="float: left;margin-left: 100px;">
            <p> © 2014 FashionStar.com, All rights reserved.</p> 
        </div>
        <div style="float: right; margin-top:15px; margin-right:30px;">
            <a href="conditions.php">Terms and Conditions</a>
            <a href="about_us.php">About Us</a> 
            <a href="#">Help</a>
        </div> 
    </div> 
</div> 
